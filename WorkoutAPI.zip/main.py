from fastapi import FastAPI
from fastapi_pagination import add_pagination
from routers import atletas, categorias, centros_treinamento

app = FastAPI(title="WorkoutAPI")

app.include_router(atletas.router)
app.include_router(categorias.router)
app.include_router(centros_treinamento.router)

add_pagination(app)  # ativa paginação global
